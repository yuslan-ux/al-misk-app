export type Siswa = {
  id: string;
  nis: string;
  nama: string;
  kelas: string;
  saldo: number;
  created_at?: string;
};