import { useAuth } from '@/context/AuthContext';
import { Navigate, Outlet } from 'react-router-dom';
import { Skeleton } from './ui/skeleton';

const PermissionRoute = ({ feature }: { feature: string }) => {
  const { profile, permissions, loading } = useAuth();

  if (loading) {
    return (
      <div className="container mx-auto p-4 sm:p-8 md:p-12">
        <Skeleton className="h-[60vh] w-full rounded-lg" />
      </div>
    );
  }

  const hasPermission = profile?.role === 'Mudir/Master' || (permissions.get(feature) ?? false);

  if (!hasPermission) {
    return <Navigate to="/" replace />;
  }

  return <Outlet />;
};

export default PermissionRoute;