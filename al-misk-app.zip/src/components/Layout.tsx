import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import MobileSidebar from './MobileSidebar';

const Layout = () => {
  return (
    <div className="min-h-screen flex bg-gray-100 dark:bg-gray-900">
      <Sidebar />
      <div className="flex flex-col flex-grow w-full md:w-auto">
        <header className="flex items-center h-16 px-4 border-b bg-white dark:bg-gray-800 md:hidden sticky top-0 z-10">
          <MobileSidebar />
          <div className="flex-grow text-center">
            <h1 className="text-lg font-semibold">AL MISK</h1>
          </div>
        </header>
        <main className="flex-grow p-4 sm:p-6 lg:p-8 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;