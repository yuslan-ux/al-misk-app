import { SidebarNav } from './SidebarNav';

const Sidebar = () => {
  return (
    <aside className="hidden md:flex md:flex-col md:w-64 flex-shrink-0 bg-gradient-to-b from-sky-600 to-indigo-800 text-white p-4">
      <SidebarNav />
    </aside>
  );
};

export default Sidebar;