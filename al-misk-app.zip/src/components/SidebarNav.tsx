import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Home, Users, Package, ShoppingCart, History, LogOut, WalletCards, FileClock, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from './ui/button';
import { supabase } from '@/integrations/supabase/client';
import { showSuccess } from '@/utils/toast';
import { useAuth } from '@/context/AuthContext';

const allNavItems = [
  { href: '/', label: 'Dashboard', icon: Home, feature: 'dashboard' },
  { href: '/siswa', label: 'Siswa', icon: Users, feature: 'siswa' },
  { href: '/produk', label: 'Produk', icon: Package, feature: 'produk' },
  { href: '/kasir', label: 'Kasir', icon: ShoppingCart, feature: 'kasir' },
  { href: '/riwayat', label: 'Riwayat', icon: History, feature: 'riwayat' },
  { href: '/saldo-massal', label: 'Saldo Massal', icon: WalletCards, feature: 'saldo-massal' },
  { href: '/log-penghapusan', label: 'Log Hapus', icon: FileClock, feature: 'log-penghapusan' },
];

const adminNavItems = [
    { href: '/settings', label: 'Pengaturan', icon: Settings, feature: 'settings' },
];

export const SidebarNav = ({ onLinkClick }: { onLinkClick?: () => void }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { profile, permissions } = useAuth();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    showSuccess('Anda telah berhasil keluar.');
    navigate('/login');
    if (onLinkClick) onLinkClick();
  };

  const handleLinkClick = () => {
    if (onLinkClick) onLinkClick();
  };

  const visibleNavItems = allNavItems.filter(item => 
    profile?.role === 'Mudir/Master' || permissions.get(item.feature)
  );

  const visibleAdminNavItems = adminNavItems.filter(item =>
    profile?.role === 'Mudir/Master' || permissions.get(item.feature)
  );

  return (
    <div className="flex flex-col h-full">
      <div className="flex flex-col items-center text-center py-8 mb-4">
        <h1 className="text-3xl font-bold tracking-wider text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.3)]">AL MISK</h1>
        <p className="text-sm text-sky-200 mt-1">Bersama Menuju Surga</p>
      </div>
      <nav className="flex-grow">
        <ul>
          {visibleNavItems.map((item) => (
            <li key={item.label}>
              <Link
                to={item.href}
                onClick={handleLinkClick}
                className={cn(
                  'flex items-center gap-3 px-4 py-3 my-1 rounded-lg transition-all duration-200 ease-in-out',
                  location.pathname === item.href
                    ? 'bg-black/20 text-white font-semibold'
                    : 'text-indigo-100 hover:bg-black/20 hover:text-white'
                )}
              >
                <item.icon className="h-5 w-5" />
                <span>{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
        {visibleAdminNavItems.length > 0 && (
            <>
                <hr className="my-4 border-indigo-500" />
                <ul>
                    {visibleAdminNavItems.map((item) => (
                         <li key={item.label}>
                            <Link
                                to={item.href}
                                onClick={handleLinkClick}
                                className={cn(
                                'flex items-center gap-3 px-4 py-3 my-1 rounded-lg transition-all duration-200 ease-in-out',
                                location.pathname === item.href
                                    ? 'bg-black/20 text-white font-semibold'
                                    : 'text-indigo-100 hover:bg-black/20 hover:text-white'
                                )}
                            >
                                <item.icon className="h-5 w-5" />
                                <span>{item.label}</span>
                            </Link>
                        </li>
                    ))}
                </ul>
            </>
        )}
      </nav>
      <div className="mt-auto">
        <Button variant="ghost" className="w-full justify-start gap-3 text-indigo-100 hover:bg-black/20 hover:text-white" onClick={handleLogout}>
          <LogOut className="h-5 w-5" />
          <span>Keluar</span>
        </Button>
      </div>
    </div>
  );
};