import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

export type Profile = {
  id: string;
  email: string | null;
  full_name: string | null;
  avatar_url: string | null;
  role: 'Mudir/Master' | 'Musrifah';
};

type AuthContextType = {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  permissions: Map<string, boolean>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [permissions, setPermissions] = useState<Map<string, boolean>>(new Map());

  useEffect(() => {
    const getSessionAndProfile = async () => {
      setLoading(true);
      const { data: { session } } = await supabase.auth.getSession();
      setSession(session);
      const currentUser = session?.user ?? null;
      setUser(currentUser);

      if (currentUser) {
        const { data: userProfile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', currentUser.id)
          .single();
        setProfile(userProfile as Profile | null);

        if (userProfile) {
          const { data: userPermissions } = await supabase
            .from('role_permissions')
            .select('feature, can_access')
            .eq('role', userProfile.role);
          
          const permissionsMap = new Map<string, boolean>();
          userPermissions?.forEach(p => permissionsMap.set(p.feature, p.can_access));
          setPermissions(permissionsMap);
        }
      } else {
        setProfile(null);
        setPermissions(new Map());
      }
      setLoading(false);
    };

    getSessionAndProfile();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      setSession(session);
      const currentUser = session?.user ?? null;
      setUser(currentUser);
      setLoading(true);

      if (currentUser) {
        const { data: userProfile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', currentUser.id)
          .single();
        setProfile(userProfile as Profile | null);
        
        if (userProfile) {
          const { data: userPermissions } = await supabase
            .from('role_permissions')
            .select('feature, can_access')
            .eq('role', userProfile.role);
          
          const permissionsMap = new Map<string, boolean>();
          userPermissions?.forEach(p => permissionsMap.set(p.feature, p.can_access));
          setPermissions(permissionsMap);
        }
      } else {
        setProfile(null);
        setPermissions(new Map());
      }
      setLoading(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return (
    <AuthContext.Provider value={{ session, user, profile, loading, permissions }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};