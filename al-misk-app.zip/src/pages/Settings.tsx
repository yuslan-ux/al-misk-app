import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Profile } from "@/context/AuthContext";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { showSuccess, showError } from "@/utils/toast";
import { useAuth } from "@/context/AuthContext";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

const manageableFeatures = [
  { id: 'siswa', label: 'Manajemen Siswa' },
  { id: 'produk', label: 'Manajemen Produk' },
  { id: 'kasir', label: 'Kasir (POS)' },
  { id: 'riwayat', label: 'Riwayat Saldo' },
  { id: 'saldo-massal', label: 'Update Saldo Massal' },
  { id: 'log-penghapusan', label: 'Log Penghapusan Transaksi' },
];

const SettingsPage = () => {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const { data: profiles, isLoading: isLoadingProfiles } = useQuery<Profile[]>({
    queryKey: ["profiles"],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("*");
      if (error) throw new Error(error.message);
      return data || [];
    },
  });

  const { data: musrifahPermissions, isLoading: isLoadingPermissions } = useQuery({
    queryKey: ['role_permissions', 'Musrifah'],
    queryFn: async () => {
        const { data, error } = await supabase
            .from('role_permissions')
            .select('*')
            .eq('role', 'Musrifah');
        if (error) throw error;
        const permissionsMap = new Map<string, boolean>();
        data.forEach(p => permissionsMap.set(p.feature, p.can_access));
        return permissionsMap;
    }
  });

  const updateRoleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: string }) => {
      const { error } = await supabase
        .from("profiles")
        .update({ role })
        .eq("id", userId);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["profiles"] });
      showSuccess("Peran pengguna berhasil diperbarui.");
    },
    onError: (error: Error) => {
      showError(error.message);
    },
  });

  const updatePermissionMutation = useMutation({
    mutationFn: async ({ feature, can_access }: { feature: string; can_access: boolean }) => {
        const { error } = await supabase
            .from('role_permissions')
            .upsert({ role: 'Musrifah', feature, can_access }, { onConflict: 'role,feature' });
        if (error) throw error;
    },
    onSuccess: (_, variables) => {
        queryClient.setQueryData(['role_permissions', 'Musrifah'], (oldData: Map<string, boolean> | undefined) => {
            const newData = new Map(oldData);
            newData.set(variables.feature, variables.can_access);
            return newData;
        });
        queryClient.invalidateQueries({ queryKey: ['role_permissions', 'Musrifah'] });
        showSuccess("Hak akses berhasil diperbarui.");
    },
    onError: (error: Error) => {
        showError(error.message);
    }
  });

  const handleRoleChange = (userId: string, role: string) => {
    updateRoleMutation.mutate({ userId, role });
  };

  const handlePermissionChange = (feature: string, checked: boolean) => {
    updatePermissionMutation.mutate({ feature, can_access: checked });
  };

  return (
    <div className="container mx-auto py-10 space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Pengaturan</h1>
        <p className="text-muted-foreground">Kelola pengguna dan hak akses sistem.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Hak Akses Peran Musrifah</CardTitle>
          <CardDescription>
            Atur menu dan fitur apa saja yang dapat diakses oleh pengguna dengan peran "Musrifah".
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingPermissions ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Array.from({length: 6}).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {manageableFeatures.map((feature) => (
                <div key={feature.id} className="flex items-center space-x-3 p-3 rounded-md border bg-background hover:bg-muted/50">
                  <Checkbox
                    id={feature.id}
                    checked={musrifahPermissions?.get(feature.id) ?? false}
                    onCheckedChange={(checked) => handlePermissionChange(feature.id, !!checked)}
                    disabled={updatePermissionMutation.isPending}
                  />
                  <Label htmlFor={feature.id} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex-grow">
                    {feature.label}
                  </Label>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Manajemen Pengguna</CardTitle>
          <CardDescription>
            Atur peran untuk setiap pengguna yang terdaftar di sistem.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Email</TableHead>
                  <TableHead>Nama Lengkap</TableHead>
                  <TableHead>Peran</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoadingProfiles ? (
                  Array.from({ length: 3 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-5 w-48" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                      <TableCell><Skeleton className="h-10 w-32" /></TableCell>
                    </TableRow>
                  ))
                ) : (
                  profiles?.map((profile) => (
                    <TableRow key={profile.id}>
                      <TableCell>{profile.email}</TableCell>
                      <TableCell>{profile.full_name || "Belum diatur"}</TableCell>
                      <TableCell>
                        <Select
                          value={profile.role}
                          onValueChange={(newRole) => handleRoleChange(profile.id, newRole)}
                          disabled={profile.id === user?.id || updateRoleMutation.isPending}
                        >
                          <SelectTrigger className="w-[180px]">
                            <SelectValue placeholder="Pilih peran" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Mudir/Master">Mudir/Master</SelectItem>
                            <SelectItem value="Musrifah">Musrifah</SelectItem>
                          </SelectContent>
                        </Select>
                        {profile.id === user?.id && <p className="text-xs text-muted-foreground mt-1">Anda tidak dapat mengubah peran sendiri.</p>}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SettingsPage;